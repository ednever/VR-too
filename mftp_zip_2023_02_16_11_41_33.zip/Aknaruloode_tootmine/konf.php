<?php
//$baasiaadress = 'localhost';
$baasiaadress = 'd113370.mysql.zonevs.eu';
//$baasikasutaja = 'neverovskiTARpv21';
$baasikasutaja = 'd113370_ednever';
$baasiparool = 'mby9wD@ICFVuOQn2';
//$baasinimi = 'neverovskiTARpv21';
$baasinimi = 'd113370_baasedn';
$yhendus=new mysqli($baasiaadress, $baasikasutaja, $baasiparool, $baasinimi);